package br.com.basis.consulta.domain.enumeration;

/**
 * The TipoPagador enumeration.
 */
public enum TipoPagador {
    SUS, OUTROS_CONVENIOS
}

/**
 * Spring Data Elasticsearch repositories.
 */
package br.com.basis.consulta.repository.search;

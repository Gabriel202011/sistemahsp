package br.com.basis.consulta.domain.enumeration;

/**
 * The Pagador enumeration.
 */
public enum Pagador {
    SUS, OUTROS_CONVENIOS
}

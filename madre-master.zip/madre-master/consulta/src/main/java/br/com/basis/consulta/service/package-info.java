/**
 * Service layer beans.
 */
package br.com.basis.consulta.service;

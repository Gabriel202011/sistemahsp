/**
 * Spring MVC REST controllers.
 */
package br.com.basis.consulta.web.rest;

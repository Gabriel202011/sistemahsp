package br.com.basis.consulta.domain.enumeration;

/**
 * The Turno enumeration.
 */
public enum Turno {
    MATUTINO, VESPERTINO, NOTURNO
}

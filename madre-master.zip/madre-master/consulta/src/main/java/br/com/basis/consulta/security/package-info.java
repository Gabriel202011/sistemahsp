/**
 * Spring Security configuration.
 */
package br.com.basis.consulta.security;

package br.com.basis.madre.madreexames.domain.enumeration;

/**
 * The Abrangencia enumeration.
 */
public enum Abrangencia {
    AMBULATORIO, INTERNACAO, AMBOS
}

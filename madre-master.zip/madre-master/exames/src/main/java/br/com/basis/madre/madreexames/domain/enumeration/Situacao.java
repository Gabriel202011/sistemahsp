package br.com.basis.madre.madreexames.domain.enumeration;

/**
 * The Situacao enumeration.
 */
public enum Situacao {
    A_COLETAR, AREA_EXECUTORA, COLETADO
}

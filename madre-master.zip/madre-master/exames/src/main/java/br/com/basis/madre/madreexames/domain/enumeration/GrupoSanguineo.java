package br.com.basis.madre.madreexames.domain.enumeration;

/**
 * The GrupoSanguineo enumeration.
 */
public enum GrupoSanguineo {
    O, A, B, AB, INDETERMINADO
}

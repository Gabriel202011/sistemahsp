package br.com.basis.madre.madreexames.domain.enumeration;

/**
 * The Sexo enumeration.
 */
public enum Sexo {
    FEMININO, MASCULINO, IGNORADO
}

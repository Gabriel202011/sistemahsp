package br.com.basis.madre.madreexames.domain.enumeration;

/**
 * The UnidadeDeMedida enumeration.
 */
public enum UnidadeDeMedida {
    MILILITRO, FRASCO
}

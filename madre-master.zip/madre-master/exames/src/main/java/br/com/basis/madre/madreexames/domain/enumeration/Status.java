package br.com.basis.madre.madreexames.domain.enumeration;

/**
 * The Status enumeration.
 */
public enum Status {
    INICIADO, COMPLETO, INTERROMPIDO
}

package br.com.basis.madre.madreexames.domain.enumeration;

/**
 * The Raca enumeration.
 */
public enum Raca {
    BRANCA, PRETA, PARDA, AMARELA, INDIGENA
}

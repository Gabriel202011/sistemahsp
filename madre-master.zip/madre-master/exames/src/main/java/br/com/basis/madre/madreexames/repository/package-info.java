/**
 * Spring Data JPA repositories.
 */
package br.com.basis.madre.madreexames.repository;

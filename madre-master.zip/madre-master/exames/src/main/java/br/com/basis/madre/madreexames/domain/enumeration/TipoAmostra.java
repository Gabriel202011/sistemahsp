package br.com.basis.madre.madreexames.domain.enumeration;

/**
 * The TipoAmostra enumeration.
 */
public enum TipoAmostra {
    DOADOR, RECEPTOR
}

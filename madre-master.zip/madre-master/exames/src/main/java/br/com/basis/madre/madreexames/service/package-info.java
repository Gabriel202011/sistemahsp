/**
 * Service layer beans.
 */
package br.com.basis.madre.madreexames.service;

package br.com.basis.madre.madreexames.domain.enumeration;

/**
 * The Dia enumeration.
 */
public enum Dia {
    DOMINGO, SEGUNDA_FEIRA, TERCA_FEIRA, QUARTA_FEIRA, QUINTA_FEIRA, SEXTA_FEIRA, SABADO
}

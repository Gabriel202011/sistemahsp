package br.com.basis.madre.madreexames.domain.enumeration;

/**
 * The OrigemTipoAmostra enumeration.
 */
public enum OrigemTipoAmostra {
    NASCIMENTO, AMBULATORIO, INTERNACAO, URGENCIA, PACIENTE, DOACAO, HOSPITAL, CIRURGIA
}

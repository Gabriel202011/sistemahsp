/**
 * View Models used by Spring MVC REST controllers.
 */
package br.com.basis.madre.madreexames.web.rest.vm;

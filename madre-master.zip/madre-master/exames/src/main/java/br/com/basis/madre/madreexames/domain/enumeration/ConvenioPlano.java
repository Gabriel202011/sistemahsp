package br.com.basis.madre.madreexames.domain.enumeration;

/**
 * The ConvenioPlano enumeration.
 */
public enum ConvenioPlano {
    SUS_INTERNACAO, SUS_PLANO_AMBULATORIO
}

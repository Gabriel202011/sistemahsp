package br.com.basis.madre.madreexames.domain.enumeration;

/**
 * The OrigemAmostra enumeration.
 */
public enum OrigemAmostra {
    HUMANO, NAO_HUMANO
}

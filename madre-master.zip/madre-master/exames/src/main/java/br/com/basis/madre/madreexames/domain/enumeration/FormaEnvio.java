package br.com.basis.madre.madreexames.domain.enumeration;

/**
 * The FormaEnvio enumeration.
 */
public enum FormaEnvio {
    CORREIO, FAX
}

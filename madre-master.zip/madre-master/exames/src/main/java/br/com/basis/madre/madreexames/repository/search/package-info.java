/**
 * Spring Data Elasticsearch repositories.
 */
package br.com.basis.madre.madreexames.repository.search;

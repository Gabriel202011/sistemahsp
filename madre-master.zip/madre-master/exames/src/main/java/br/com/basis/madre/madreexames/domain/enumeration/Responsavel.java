package br.com.basis.madre.madreexames.domain.enumeration;

/**
 * The Responsavel enumeration.
 */
public enum Responsavel {
    COLETADOR, SOLICITANTE, PACIENTE
}
